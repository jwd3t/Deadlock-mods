Sekiro Death & Victory Mod for Deadlock
==========================
Features:
- Your own death: the red Sekiro kanji 死 (DEATH) on screen with the Sekiro death sound, once, in every mode
- Dying while holding the Rejuvenator's rebirth: the grey fake-death 死, as in Sekiro when you can resurrect
- Victor's Shocking Reanimation: the grey fake-death 死 over the revive bar
- Winning the match: 忍殺 (SHINOBI EXECUTION) on the match-end screen with the Sekiro victory fanfare
- Rebuilt from the current game files, so it never reverts other game changes
- 100% VAC-safe client-side cosmetic mod

Installation:
1. Deadlock Mod Manager (Recommended):
   Drag and drop Sekiro_Death_Victory_Mod.zip directly into Deadlock Mod Manager.
2. Manual Installation:
   Copy pak01_dir.vpk into your Deadlock addons folder:
   <Steam>/steamapps/common/Deadlock/game/citadel/addons/
