Sekiro Death, Victory & Resurrection Mod for Deadlock
========================================
Features:
- True Death Screen: Calligraphic crimson kanji '死' (Death) centered on screen with authentic Sekiro death stinger audio
- Victory: Calligraphic kanji '忍殺' (Shinobi Execution) with triumphant Sekiro gong and victory audio upon winning the match
- Fake Death for Victor (Frank): Taking lethal damage with revival ultimate active triggers the misty '回生' (Resurrection) state before shocking reanimation
- Fake Death for Rejuvenator: Carrying the Mid-Boss Rejuvenator buff triggers the Sekiro '回生' resurrection effect upon defeat
- 100% VAC-safe client-side cosmetic mod

Installation:
1. Deadlock Mod Manager (Recommended):
   Drag and drop Sekiro_Death_Victory_Mod.zip directly into Deadlock Mod Manager.
2. Manual Installation:
   Copy pak01_dir.vpk into your Deadlock addons folder:
   <Steam>/steamapps/common/Deadlock/game/citadel/addons/
