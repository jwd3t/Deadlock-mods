Sekiro Deathblow Red Dot Mod for Deadlock
============================
Features:
- Sekiro deathblow dot fitted to in-game footage: pure red soft disc on parried / stunned enemies
- Sekiro timing: ~0.17s fade-in while settling from 1.25x size, ~0.23s fade-out
- Authentic heavy Sekiro posture break and deathblow gong sound effect
- Clean 100% VAC-safe client-side cosmetic mod

Installation:
1. Deadlock Mod Manager (Recommended):
   Drag and drop Sekiro_Deathblow_Mod.zip directly into Deadlock Mod Manager.
2. Manual Installation:
   Copy pak01_dir.vpk into your Deadlock addons folder:
   <Steam>/steamapps/common/Deadlock/game/citadel/addons/
