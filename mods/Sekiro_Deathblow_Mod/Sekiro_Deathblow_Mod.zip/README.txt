Sekiro Deathblow Red Dot Mod for Deadlock
============================
Features:
- Sekiro deathblow dot built like Sekiro and Deadlock's own marks: it tints the enemy red under it and glows as light, instead of a flat sticker
- Appears large and faint and contracts into the dot, then spins slowly and breathes; fades out over 0.2s when the stun ends
- Drawn on top of the enemy body, unaffected by scene lighting
- Authentic heavy Sekiro posture break and deathblow gong sound effect
- Clean 100% VAC-safe client-side cosmetic mod

Installation:
1. Deadlock Mod Manager (Recommended):
   Drag and drop Sekiro_Deathblow_Mod.zip directly into Deadlock Mod Manager.
2. Manual Installation:
   Copy pak01_dir.vpk into your Deadlock addons folder:
   <Steam>/steamapps/common/Deadlock/game/citadel/addons/
