Sekiro Deathblow Red Dot Mod for Deadlock
============================
Features:
- Sekiro deathblow dot built from an isolated Sekiro reference: orange-red disc, fluffy edge, sparkly core
- Drawn on top of the enemy body and self-illuminated, so bright scenes do not wash it out
- ~0.12s fade-in settling from 1.25x size, ~0.18s fade-out expanding to 1.3x
- Authentic heavy Sekiro posture break and deathblow gong sound effect
- Clean 100% VAC-safe client-side cosmetic mod

Installation:
1. Deadlock Mod Manager (Recommended):
   Drag and drop Sekiro_Deathblow_Mod.zip directly into Deadlock Mod Manager.
2. Manual Installation:
   Copy pak01_dir.vpk into your Deadlock addons folder:
   <Steam>/steamapps/common/Deadlock/game/citadel/addons/
