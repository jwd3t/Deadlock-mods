Sekiro Deathblow Red Dot Mod (PRUEBA granulado animado) for Deadlock
=======================================================
TEST BUILD - animated grain:
- Same as deathblow-v2.1 plus a 20% grain that moves (16-frame loop at 20 fps), in both the light and the tint layer

Installation:
1. Deadlock Mod Manager (Recommended):
   Drag and drop Sekiro_Deathblow_Mod.zip directly into Deadlock Mod Manager.
2. Manual Installation:
   Copy pak01_dir.vpk into your Deadlock addons folder:
   <Steam>/steamapps/common/Deadlock/game/citadel/addons/
