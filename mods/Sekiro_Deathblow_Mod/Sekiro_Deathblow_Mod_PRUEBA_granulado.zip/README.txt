Sekiro Deathblow Red Dot Mod (PRUEBA granulado + centro naranja) for Deadlock
================================================================
TEST BUILD:
- Same as deathblow-v2.1 plus a 20% grain that moves (16-frame loop at 20 fps)
- Warm orange core as measured in Sekiro, instead of white

Installation:
1. Deadlock Mod Manager (Recommended):
   Drag and drop Sekiro_Deathblow_Mod.zip directly into Deadlock Mod Manager.
2. Manual Installation:
   Copy pak01_dir.vpk into your Deadlock addons folder:
   <Steam>/steamapps/common/Deadlock/game/citadel/addons/
