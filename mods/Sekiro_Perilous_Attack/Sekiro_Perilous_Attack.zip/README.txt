Sekiro Perilous Attack ("危") Mod for Deadlock
======================================================
Features:
- Single Sekiro Perilous Attack ("危") Kanji hovering above hero head
- Calibrated with Trophy Collector overhead technique (+110 offset) to fit all hero heights
- Half size (radius 21.0) for authentic, clean, non-obtrusive telegraph
- Authentic Sekiro Perilous Attack sound with boosted volume (+8 dB in-engine gain)
- Full sound duration fix (no cut-off)

Installation:
Drop pak01_dir.vpk into your Deadlock addons folder:
<Steam>/steamapps/common/Deadlock/game/citadel/addons/
Or load it with Deadlock Mod Manager.
