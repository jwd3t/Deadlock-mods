Sekiro Perilous Attack True Warning Mod for Deadlock
=======================================
Features (True Version - Authentic to Sekiro):
- Animated Danger Kanji '危' flipbook with flowing white energy streaks across brush strokes and expanding shockwave aura pulse
- Warning ONLY appears above your head when an enemy charges heavy melee nearby (128 units / 13m proximity)
- Silent when you attack (100% self-immunity)
- Calibrated height (+75.0) resting directly above the hero's head
- Authentic half-size radius (21.0) for a clean, non-obtrusive telegraph
- Authentic Sekiro Perilous Attack sound with boosted in-engine gain (+8 dB) and full duration fix
- 100% VAC-safe client-side cosmetic mod

Installation:
1. Deadlock Mod Manager (Recommended):
   Drag and drop Sekiro_Perilous_Attack_True.zip directly into Deadlock Mod Manager.
2. Manual Installation:
   Copy pak01_dir.vpk into your Deadlock addons folder:
   <Steam>/steamapps/common/Deadlock/game/citadel/addons/
